#!/bin/bash
# Created by เด็กสังขะ นครเมืองสเร็น
curl https://m.facebook.com/bnelove.zc
echo ""
